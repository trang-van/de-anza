package adapter;

public interface Studentdata {
	 public final boolean DEBUG = true;
     public void statistics();
     public void printscores(int studentid);
}